<?php
return array (
  'ceshi.cm' => 
  array (
    'id' => 1,
    'cid' => '52',
    'dirname' => 'test2',
    'urlrule_pic' => '',
    'urlrule_ban' => '0',
    'themetype' => '1',
    'arctype_dirname' => 'news',
  ),
);
?>