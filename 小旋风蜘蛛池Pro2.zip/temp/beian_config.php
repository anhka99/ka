<?php
return array (
  'ceshi.cm' => 'ceshi.cm----辽ICP备12345678号',
);
?>