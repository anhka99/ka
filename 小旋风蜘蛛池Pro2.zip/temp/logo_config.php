<?php
return array (
  'ceshi.cm' => 'ceshi.cm----/temp/banner/logo_2022.png',
);
?>